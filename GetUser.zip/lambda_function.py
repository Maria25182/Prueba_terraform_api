import boto3
from boto3.dynamodb.conditions import Key
import json

def find_user(id, dynamodb=None):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('user')
    response = table.scan(
        FilterExpression=Key('id').eq(id) & Key('deleted').eq('0'),
        ProjectionExpression="#di, address, City, Country, email, first_name, last_name, suite, phone_number, #user_id, zip_code, telephone, pin",
        ExpressionAttributeNames={"#di": "id", "#user_id": "user_id"}
    )
    return response['Items']

def lambda_handler(event, context):
    id = event.get('queryStringParameters', {}).get('id')
    items_found = find_user(id)

    if items_found:
        return {
            'statusCode': 200,
            'body': json.dumps(items_found),  # Convert the list to a JSON string
            'headers': {
                'Content-Type': 'application/json'  # Add content type header
            }
        }
    else:
        return {
            'statusCode': 404,  # Use 404 for not found errors
            'body': json.dumps({'message': 'User not found'}),  # Convert the message to a JSON string
            'headers': {
                'Content-Type': 'application/json'  # Add content type header
            }
        }
